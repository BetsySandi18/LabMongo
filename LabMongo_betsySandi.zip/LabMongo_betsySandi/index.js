const express= require('express');
const router = express.Router();

const Task= require('.//models/Productora');
const Task2= require('.//models/Peli');


//Selects a la base 
router.get('/',async (req, res) =>{
    const tasks= await Task.find();
    const tasks2= await Task2.find();
    const nombreSelect= req.body.SelectTitulo;
    const infor= await Task2.find({nombre:nombreSelect});
    const franquiciaSelect= req.body.SelectTitulo;
    const info2= await Task2.find({nombre:nombreSelect});
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
     const productora_string=req.body.selectInfo5;
    const info5=await Task2.find({companiaProductora:productora_string});
    
    const fechaIni=req.body.Fecha1;
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEstreno:""}]});

    res.render('index',{
        tasks,
        tasks2,
        infor, 
        info2,
        info3,
        info5,
        inforf

    });
    
});



router.post('/selectInfoPeli',async (req, res) =>{
    console.log(req.body);
    const nombreSelect= req.body.SelectTitulo;
    console.log("--------")
    const infor= await Task2.find({nombre:nombreSelect});
    const tasks= await Task.find();
    const tasks2= await Task2.find();
    const franquiciaSelect= req.body.SelectFranquicia;
    const info2= await Task2.find({franquicia:franquiciaSelect});
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
     const productora_string=req.body.selectInfo5;
    const info5=await Task2.find({companiaProductora:productora_string});
    
    const fechaIni=req.body.Fecha1;
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEstreno:""}]});
    
    console.log(infor);
    res.render('index',{
        tasks,
        tasks2,
        infor,
        info2,
        info3,
        info5,
        inforf
        
    });
});

router.post('/selectInfoFecha',async (req, res) =>{
    console.log(req.body);
    console.log("--------")
    
    const fechaI=req.body.Fecha1;
    const fechaIni=new Date(fechaI);
    console.log(fechaI);
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEsterno:{$gte: fechaIni}},{Año_Estreno:{$lte: fechaFinal}}]});
    console.log(inforf);
    
    
    const franquiciaSelect= req.body.SelectFranquicia;
    const info2= await Task2.find({franquicia:franquiciaSelect});
    const nombreSelect= req.body.SelectTitulo;
    const infor= await Task2.find({nombre:nombreSelect});
    const tasks= await Task.find();
    const tasks2= await Task2.find();
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
    const productora_string=req.body.selectInfo5;
    const info5=await Task2.find({companiaProductora:productora_string});
    res.render('index',{
        tasks,
        tasks2,
        infor,
        info2,
        info3,
        info5,
        inforf
        
    });
});

router.post('/selectInfoFranquicia',async (req, res) =>{
    console.log(req.body);
    console.log("--------")
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
    console.log(info3);
    const franquiciaSelect= req.body.SelectFranquicia;
    const info2= await Task2.find({franquicia:franquiciaSelect});
    console.log(info2);
    const nombreSelect= req.body.SelectTitulo;
    const infor= await Task2.find({nombre:nombreSelect});
    const tasks= await Task.find();
    const tasks2= await Task2.find();
    const productora_string=req.body.selectInfo5;
    const info5=await Task2.find({companiaProductora:productora_string});
    console.log(infor);
    const fechaIni=req.body.Fecha1;
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEstreno:""}]});
    res.render('index',{
        tasks,
        tasks2,
        infor,
        info2,
        info3,
        info5,
        inforf
        
    });
});

router.post('/selectInfoProdu4',async (req, res) =>{
    console.log(req.body);
    console.log("--------")
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
    console.log(info3);
    const franquiciaSelect= req.body.SelectFranquicia;
    const info2= await Task2.find({franquicia:franquiciaSelect});
    console.log(info2);
    const nombreSelect= req.body.SelectTitulo;
    const infor= await Task2.find({nombre:nombreSelect});
    const tasks= await Task.find();
    const tasks2= await Task2.find();
     const productora_string=req.body.selectInfo5;
    const info5=await Task2.find({companiaProductora:productora_string});
    console.log(infor);
    const fechaIni=req.body.Fecha1;
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEstreno:""}]});
    res.render('index',{
        tasks,
        tasks2,
        infor,
        info2,
        info3,
        info5,
        inforf
        
    });
});


router.post('/selectInfo5',async (req, res) =>{
    console.log(req.body);
    console.log("--------");
    const productora_string=req.body.selectInfo5;
    const datos=await Task2.find({companiaProductora:productora_string});
    console.log(datos);
    var valores=[];
    for(var i=0;i<datos.length;i++){
        valores.push(datos[i].duracion);
    }
      var max=Math.max.apply(null,valores);
      var min=Math.min.apply(null,valores);

      let sum = valores.reduce((previous, current) => current += previous);
      let avg=sum/valores.length;
      const cant_pelis=await Task2.find({companiaProductora:productora_string}).count();
    var info5={
    "Cant_Pelis":cant_pelis,
    "Max":max,
    "Min":min,
    "Avg":avg
    };
    console.log(info5);
    
    const productora_seleccionada_string=req.body.selectInfoProdu4;
    const info3=await Task2.find({companiaProductora:productora_seleccionada_string});
    console.log(info3);
    const franquiciaSelect= req.body.SelectFranquicia;
    const info2= await Task2.find({franquicia:franquiciaSelect});
    console.log(info2);
    const nombreSelect= req.body.SelectTitulo;
    const infor= await Task2.find({nombre:nombreSelect});
    const tasks= await Task.find();
    const tasks2= await Task2.find();
    const fechaIni=req.body.Fecha1;
    const fechaFinal=req.body.Fech2;
    const inforf=await Task2.find({$and:[{anoEstreno:""}]});
    console.log(infor);
    res.render('index',{
        tasks,
        tasks2,
        infor,
        info2,
        info3,
        info5,
        inforf
        
    });
});




router.post('/add', async (req, res) =>{
    const task =new Task(req.body);
    await task.save();
    console.log(req.body);
    res.redirect('/');
});

router.post('/add2',async (req, res) =>{
    const task =new Task2(req.body);
    await task.save();
    console.log(req.body);
    res.redirect('/');
});

router.get('/eliminar/:id',async(req,res)=>{
    
    const { id } = req.params;
    await Task.remove({_id:id})
    res.redirect('/');
    
});

router.get('/eliminar2/:id',async(req,res)=>{
    
    const { id } = req.params;
    await Task2.remove({_id:id})
    res.redirect('/');
    
});

router.get('/editar/:id', async(req,res)=>{
    
    const { id } = req.params;
    const task = await Task.findById(id);
    res.render('editar',{
        task
    });
    
});

router.post('/editar/:id', async(req,res)=>{
    
    const { id } = req.params;
    await Task.update({_id:id}, req.body);
    res.redirect('/')
});


router.get('/editar2/:id', async(req,res)=>{
    
    const { id } = req.params;
    const task = await Task2.findById(id);
    console.log(task.id);
    res.render('editar2',{
        task
    });
    
});

router.post('/editar2/:id', async(req,res)=>{
    
    const { id } = req.params;
    await Task2.update({_id:id}, req.body);
    res.redirect('/')
});




module.exports= router;