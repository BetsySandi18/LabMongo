const path = require('path');
const express = require('express');
const morgan = require('morgan');
const mongoose = require('mongoose');

const app = express();

//Concectar a mongodb 
mongoose.connect("mongodb://localhost:27017/MovieBD",{ useNewUrlParser: true })
.then((res) => console.log('DB connectada'))
.catch(err => console.log(err));


const indexRoutes= require('./index');


//Settings
app.set('port', process.env.PORT||3000);
app.set('views', path.join(__dirname,'views'));
app.set('view engine', 'ejs');

app.use(morgan('dev'));
app.use(express.urlencoded({extended:false}));
app.use('/',indexRoutes);



app.listen(app.get('port'),() =>{
    console.log(`Server on port ${app.get('port')}`);
    
});
           
           


