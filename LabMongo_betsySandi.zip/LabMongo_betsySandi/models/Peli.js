const mongoose = require('mongoose');
const Schema= mongoose.Schema;

const PeliculaSchema= new Schema({
    nombre: String,
    genero: String,
    nombreDirector: String,
    franquicia: String,
    pais: String,
    anoEsterno: Date,
    duracion: Number,
    companiaProductora: String,
    actores: [String]
});
const Pelicula = mongoose.model('Pelicula', PeliculaSchema);
module.exports= Pelicula;