const mongoose = require('mongoose');
const Schema= mongoose.Schema;

const ProductoraSchema= new Schema({
    nombre: String,
    anoFundacion: Number,
    sitioWeb: String,
});

const Productora = mongoose.model('Productora', ProductoraSchema);
module.exports= Productora;